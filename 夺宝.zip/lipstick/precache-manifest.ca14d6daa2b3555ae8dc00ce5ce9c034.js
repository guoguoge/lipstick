self.__precacheManifest = [
  {
    "url": "assets/js/1561544003778-layout.6fcd05bf098ba46d1c3b.js"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "robots.txt"
  },
  {
    "url": "assets/js/1561544003778-login.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-actionCommodityDetail~addAddress~address~balance~binding~center~changePassword~commodityDetail~login~c134ccbc.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-action~actionCommodityDetail~addAddress~address~balance~binding~center~changePassword~commodityDetai~f7a3dc4a.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-action~actionCommodityDetail~commodityDetail~home.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-action~home.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-addAddress.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-addAddress~address~balance~binding~center~changePassword~login~password~recharge~recordAuction~recor~0872f388.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-address.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-address~recordTreasure.6fcd05bf098ba46d1c3b.js"
  },
  {
    "revision": "d2c68528e84b4c04eabfb67003f77aff",
    "url": "index.html"
  },
  {
    "url": "assets/js/1561544003778-app.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-balance.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-balance~center.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-binding.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-center.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-changePassword.6fcd05bf098ba46d1c3b.js"
  },
  {
    "revision": "fd7d2a8cc51e058554477c33f27e24bd",
    "url": "img/logo.fd7d2a8c.png"
  },
  {
    "url": "assets/js/1561544003778-chunk-vendors.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-commodityDetail.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-game.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-home.6fcd05bf098ba46d1c3b.js"
  },
  {
    "revision": "0c3e68838da026adc9516d63ed20e3fe",
    "url": "img/avater.0c3e6883.png"
  },
  {
    "url": "assets/js/1561544003778-actionCommodityDetail~addAddress~binding~commodityDetail.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-password.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-recharge.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-recharge~withdrawal.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-recordAuction.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-recordAuction~recordWithdraw.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-recordLipstick.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-recordTreasure.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-recordWithdraw.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-register.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-withdrawal.6fcd05bf098ba46d1c3b.js"
  },
  {
    "revision": "72a3c6bd0f41fbbcb4e1d1b1347abd76",
    "url": "img/wechat.72a3c6bd.svg"
  },
  {
    "revision": "33874ca52c52c9f75f61e8d18de988d0",
    "url": "img/tab01.33874ca5.png"
  },
  {
    "revision": "d72a2584cc8e7ef1d59f9089948d0697",
    "url": "img/noimg.d72a2584.png"
  },
  {
    "revision": "019791d75c9a15f888547364fcf54d8f",
    "url": "img/wechatpay.019791d7.png"
  },
  {
    "revision": "4c0f345b08921741cb99bd75fa146b80",
    "url": "img/friend.4c0f345b.svg"
  },
  {
    "revision": "70fad0bc258b903eb39550ab3eacbeaa",
    "url": "img/tab02active.70fad0bc.png"
  },
  {
    "revision": "5d73e51ae17cbff2cb6fd6ee30308c25",
    "url": "img/tab01active.5d73e51a.png"
  },
  {
    "url": "assets/js/1561544003778-actionCommodityDetail.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/js/1561544003778-action.6fcd05bf098ba46d1c3b.js"
  },
  {
    "url": "assets/css/chunk-vendors.cfa2659c32f132801d95.1561544003778.css"
  },
  {
    "url": "assets/css/app.24c99bf6e6e5a08f8f7e.1561544003778.css"
  }
];