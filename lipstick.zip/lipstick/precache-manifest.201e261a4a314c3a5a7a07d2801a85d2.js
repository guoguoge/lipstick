self.__precacheManifest = [
  {
    "url": "assets/js/1561430792383-home.c88c2f885b1cd2361fc3.js"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "robots.txt"
  },
  {
    "url": "assets/js/1561430792383-layout.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-actionCommodityDetail~addAddress~address~balance~binding~center~changePassword~commodityDetail~login~62e71851.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-action~actionCommodityDetail~addAddress~address~balance~binding~center~changePassword~commodityDetai~5cc17906.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-action~actionCommodityDetail~commodityDetail~home.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-action~home.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-addAddress.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-addAddress~address~balance~binding~center~changePassword~login~password~recharge~recordAuction~recor~52f993e1.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-address.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-address~recordTreasure.c88c2f885b1cd2361fc3.js"
  },
  {
    "revision": "4b6713934fae9068512970002c11cc94",
    "url": "index.html"
  },
  {
    "url": "assets/js/1561430792383-app.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-balance.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-balance~center.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-binding.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-center.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-changePassword.c88c2f885b1cd2361fc3.js"
  },
  {
    "revision": "fd7d2a8cc51e058554477c33f27e24bd",
    "url": "img/logo.fd7d2a8c.png"
  },
  {
    "url": "assets/js/1561430792383-chunk-vendors.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-commodityDetail.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-game.c88c2f885b1cd2361fc3.js"
  },
  {
    "revision": "0c3e68838da026adc9516d63ed20e3fe",
    "url": "img/avater.0c3e6883.png"
  },
  {
    "url": "assets/js/1561430792383-actionCommodityDetail~addAddress~commodityDetail.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-login.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-password.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-recharge.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-recharge~withdrawal.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-recordAuction.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-recordLipstick.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-recordTreasure.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-register.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-withdrawal.c88c2f885b1cd2361fc3.js"
  },
  {
    "revision": "72a3c6bd0f41fbbcb4e1d1b1347abd76",
    "url": "img/wechat.72a3c6bd.svg"
  },
  {
    "revision": "33874ca52c52c9f75f61e8d18de988d0",
    "url": "img/tab01.33874ca5.png"
  },
  {
    "revision": "d72a2584cc8e7ef1d59f9089948d0697",
    "url": "img/noimg.d72a2584.png"
  },
  {
    "revision": "019791d75c9a15f888547364fcf54d8f",
    "url": "img/wechatpay.019791d7.png"
  },
  {
    "revision": "4c0f345b08921741cb99bd75fa146b80",
    "url": "img/friend.4c0f345b.svg"
  },
  {
    "revision": "70fad0bc258b903eb39550ab3eacbeaa",
    "url": "img/tab02active.70fad0bc.png"
  },
  {
    "revision": "5d73e51ae17cbff2cb6fd6ee30308c25",
    "url": "img/tab01active.5d73e51a.png"
  },
  {
    "url": "assets/js/1561430792383-actionCommodityDetail.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/js/1561430792383-action.c88c2f885b1cd2361fc3.js"
  },
  {
    "url": "assets/css/chunk-vendors.60fdb0d0cfe7c50f7f8b.1561430792383.css"
  },
  {
    "url": "assets/css/app.835e152790e211498997.1561430792383.css"
  }
];