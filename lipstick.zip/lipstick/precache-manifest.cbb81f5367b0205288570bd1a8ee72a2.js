self.__precacheManifest = [
  {
    "url": "assets/js/1562148489616-layout.e5b61aae4239cf5d3c52.js"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "robots.txt"
  },
  {
    "url": "assets/js/1562148489616-login.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-actionCommodityDetail~addAddress~address~balance~binding~center~changePassword~commodityDetail~login~c134ccbc.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-action~actionCommodityDetail~addAddress~address~balance~binding~center~changePassword~commodityDetai~f7a3dc4a.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-action~actionCommodityDetail~commodityDetail~home.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-action~home.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-addAddress.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-addAddress~address~balance~binding~center~changePassword~login~password~recharge~recordAuction~recor~0872f388.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-address.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-address~recordTreasure.e5b61aae4239cf5d3c52.js"
  },
  {
    "revision": "135620ca1bbda379134e01ce1e744bc5",
    "url": "index.html"
  },
  {
    "url": "assets/js/1562148489616-app.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-balance.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-balance~center.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-binding.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-center.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-changePassword.e5b61aae4239cf5d3c52.js"
  },
  {
    "revision": "fd7d2a8cc51e058554477c33f27e24bd",
    "url": "img/logo.fd7d2a8c.png"
  },
  {
    "url": "assets/js/1562148489616-chunk-vendors.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-commodityDetail.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-game.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-home.e5b61aae4239cf5d3c52.js"
  },
  {
    "revision": "0c3e68838da026adc9516d63ed20e3fe",
    "url": "img/avater.0c3e6883.png"
  },
  {
    "url": "assets/js/1562148489616-actionCommodityDetail~addAddress~binding~commodityDetail.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-password.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-recharge.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-recharge~withdrawal.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-recordAuction.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-recordAuction~recordWithdraw.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-recordLipstick.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-recordTreasure.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-recordWithdraw.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-register.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-withdrawal.e5b61aae4239cf5d3c52.js"
  },
  {
    "revision": "72a3c6bd0f41fbbcb4e1d1b1347abd76",
    "url": "img/wechat.72a3c6bd.svg"
  },
  {
    "revision": "33874ca52c52c9f75f61e8d18de988d0",
    "url": "img/tab01.33874ca5.png"
  },
  {
    "revision": "d72a2584cc8e7ef1d59f9089948d0697",
    "url": "img/noimg.d72a2584.png"
  },
  {
    "revision": "019791d75c9a15f888547364fcf54d8f",
    "url": "img/wechatpay.019791d7.png"
  },
  {
    "revision": "4c0f345b08921741cb99bd75fa146b80",
    "url": "img/friend.4c0f345b.svg"
  },
  {
    "revision": "70fad0bc258b903eb39550ab3eacbeaa",
    "url": "img/tab02active.70fad0bc.png"
  },
  {
    "revision": "5d73e51ae17cbff2cb6fd6ee30308c25",
    "url": "img/tab01active.5d73e51a.png"
  },
  {
    "url": "assets/js/1562148489616-actionCommodityDetail.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/js/1562148489616-action.e5b61aae4239cf5d3c52.js"
  },
  {
    "url": "assets/css/chunk-vendors.cfa2659c32f132801d95.1562148489616.css"
  },
  {
    "url": "assets/css/app.fb942e1e35fcae7dca53.1562148489616.css"
  }
];