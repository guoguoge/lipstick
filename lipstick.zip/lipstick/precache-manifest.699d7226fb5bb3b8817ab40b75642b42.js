self.__precacheManifest = [
  {
    "url": "assets/js/1557223306401-home.1057a2cc6a1c04a99ba3.js"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "robots.txt"
  },
  {
    "url": "assets/js/1557223306401-layout.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-actionCommodityDetail~addAddress~address~balance~binding~center~changePassword~commodityDetail~login~62e71851.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-actionCommodityDetail~commodityDetail.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-action~actionCommodityDetail~commodityDetail~home.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-action~home.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-addAddress.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-addAddress~address~balance~binding~center~changePassword~login~password~recharge~recordAuction~recor~52f993e1.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-address.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-address~recordTreasure.1057a2cc6a1c04a99ba3.js"
  },
  {
    "revision": "9040c6a0db25d765d91892c196b77dba",
    "url": "index.html"
  },
  {
    "url": "assets/js/1557223306401-app.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-balance.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-balance~center.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-binding.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-center.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-changePassword.1057a2cc6a1c04a99ba3.js"
  },
  {
    "revision": "fd7d2a8cc51e058554477c33f27e24bd",
    "url": "img/logo.fd7d2a8c.png"
  },
  {
    "url": "assets/js/1557223306401-chunk-vendors.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-commodityDetail.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-game.1057a2cc6a1c04a99ba3.js"
  },
  {
    "revision": "0c3e68838da026adc9516d63ed20e3fe",
    "url": "img/avater.0c3e6883.png"
  },
  {
    "url": "assets/js/1557223306401-actionCommodityDetail~addAddress~commodityDetail.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-login.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-password.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-recharge.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-recharge~withdrawal.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-recordAuction.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-recordLipstick.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-recordTreasure.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-register.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-withdrawal.1057a2cc6a1c04a99ba3.js"
  },
  {
    "revision": "72a3c6bd0f41fbbcb4e1d1b1347abd76",
    "url": "img/wechat.72a3c6bd.svg"
  },
  {
    "revision": "33874ca52c52c9f75f61e8d18de988d0",
    "url": "img/tab01.33874ca5.png"
  },
  {
    "revision": "d72a2584cc8e7ef1d59f9089948d0697",
    "url": "img/noimg.d72a2584.png"
  },
  {
    "revision": "019791d75c9a15f888547364fcf54d8f",
    "url": "img/wechatpay.019791d7.png"
  },
  {
    "revision": "4c0f345b08921741cb99bd75fa146b80",
    "url": "img/friend.4c0f345b.svg"
  },
  {
    "revision": "70fad0bc258b903eb39550ab3eacbeaa",
    "url": "img/tab02active.70fad0bc.png"
  },
  {
    "revision": "5d73e51ae17cbff2cb6fd6ee30308c25",
    "url": "img/tab01active.5d73e51a.png"
  },
  {
    "url": "assets/js/1557223306401-actionCommodityDetail.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/js/1557223306401-action.1057a2cc6a1c04a99ba3.js"
  },
  {
    "url": "assets/css/chunk-vendors.131708c1ce8cfe59c43f.1557223306401.css"
  },
  {
    "url": "assets/css/app.ff61d9584fc21d6154f6.1557223306401.css"
  }
];