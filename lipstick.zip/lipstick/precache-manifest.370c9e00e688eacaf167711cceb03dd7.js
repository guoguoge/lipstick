self.__precacheManifest = [
  {
    "revision": "88bf7966da14ca4f3b17",
    "url": "assets/js/layout.4f2f1544.js"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "robots.txt"
  },
  {
    "revision": "776b990d0a20b5dc54e6",
    "url": "assets/js/login.0ee7baec.js"
  },
  {
    "revision": "cd6ebae06a2c47d896c1",
    "url": "assets/js/actionCommodityDetail~addAddress~address~balance~binding~center~changePassword~commodityDetail~login~62e71851.6a0595ae.js"
  },
  {
    "revision": "1de8888a91ed30c68f00",
    "url": "assets/js/actionCommodityDetail~commodityDetail.2a7acdc9.js"
  },
  {
    "revision": "22e9c6839590410bf49b",
    "url": "assets/js/action~actionCommodityDetail~commodityDetail~home.eb7b6a3a.js"
  },
  {
    "revision": "4422248e607349b588bf",
    "url": "assets/js/action~home.d6c4f54c.js"
  },
  {
    "revision": "320db762963732c45a89",
    "url": "assets/js/addAddress.60ee8649.js"
  },
  {
    "revision": "54a9f4504d2b7fb4fd3e",
    "url": "assets/js/addAddress~address~balance~binding~center~changePassword~login~password~recharge~recordAuction~recor~52f993e1.a4ec1d3c.js"
  },
  {
    "revision": "7ec91a1bb81c7708cae9",
    "url": "assets/js/address.620ac660.js"
  },
  {
    "revision": "f5c75c510045cc4702f1",
    "url": "assets/js/address~recordAuction~recordLipstick~recordTreasure.75d16849.js"
  },
  {
    "revision": "b06ad545074016ffca3ff381aa850118",
    "url": "index.html"
  },
  {
    "revision": "2085bd7cfb459800397a",
    "url": "assets/js/app.2b4dacff.js"
  },
  {
    "revision": "7e7dd4e7bdb08629e2e1",
    "url": "assets/js/balance.d97be822.js"
  },
  {
    "revision": "573e8589c05374443f65",
    "url": "assets/js/balance~center.cdb835a3.js"
  },
  {
    "revision": "2c8019cc325b730c49a4",
    "url": "assets/js/binding.7743d546.js"
  },
  {
    "revision": "3b9c6f596867113706d7",
    "url": "assets/js/center.f9f3bd22.js"
  },
  {
    "revision": "166a5d9680e7c936811c",
    "url": "assets/js/changePassword.e7e2b000.js"
  },
  {
    "revision": "0fee9c2cae12894e9787",
    "url": "assets/js/withdrawal.847367d3.js"
  },
  {
    "revision": "e319b24008a968815be5",
    "url": "assets/js/chunk-vendors.9a9da8f9.js"
  },
  {
    "revision": "6286aed48171f13adc67",
    "url": "assets/js/commodityDetail.2757c846.js"
  },
  {
    "revision": "47338de1ddd93c1b8df7",
    "url": "assets/js/game.4680197e.js"
  },
  {
    "revision": "8772514924cca6fd0aec",
    "url": "assets/js/home.06c42d6e.js"
  },
  {
    "revision": "e725b977a9a17fc3d5c2",
    "url": "assets/js/register.b2653a19.js"
  },
  {
    "revision": "24d81acc0e3fd45ed1ea",
    "url": "assets/js/actionCommodityDetail~addAddress~commodityDetail.02b3044d.js"
  },
  {
    "revision": "35776d8b6dfe417ad6fe",
    "url": "assets/js/password.13b04a03.js"
  },
  {
    "revision": "6036df5c46d81654fa9a",
    "url": "assets/js/recharge.d2114799.js"
  },
  {
    "revision": "cdb25e0d314d650a466f",
    "url": "assets/js/recharge~withdrawal.3183e02f.js"
  },
  {
    "revision": "c7f8d6f75a17372ad2ea",
    "url": "assets/js/recordAuction.a19dabe3.js"
  },
  {
    "revision": "0241692801589dda15dc",
    "url": "assets/js/recordLipstick.84840aa6.js"
  },
  {
    "revision": "7d0b16ab36b964708a8f",
    "url": "assets/js/recordTreasure.ab97204a.js"
  },
  {
    "revision": "70fad0bc258b903eb39550ab3eacbeaa",
    "url": "assets/img/tab02active.70fad0bc.png"
  },
  {
    "revision": "2924cf1b3d682c95f667",
    "url": "assets/js/actionCommodityDetail.757f4c6b.js"
  },
  {
    "revision": "5d73e51ae17cbff2cb6fd6ee30308c25",
    "url": "assets/img/tab01active.5d73e51a.png"
  },
  {
    "revision": "1d56b1081295bd524013",
    "url": "assets/js/action.da2fa001.js"
  },
  {
    "revision": "0c3e68838da026adc9516d63ed20e3fe",
    "url": "assets/img/avater.0c3e6883.png"
  },
  {
    "revision": "72a3c6bd0f41fbbcb4e1d1b1347abd76",
    "url": "assets/img/wechat.72a3c6bd.svg"
  },
  {
    "revision": "019791d75c9a15f888547364fcf54d8f",
    "url": "assets/img/wechatpay.019791d7.png"
  },
  {
    "revision": "33874ca52c52c9f75f61e8d18de988d0",
    "url": "assets/img/tab01.33874ca5.png"
  },
  {
    "revision": "fd7d2a8cc51e058554477c33f27e24bd",
    "url": "assets/img/logo.fd7d2a8c.png"
  },
  {
    "revision": "d698c02937cd281ab1a2ed7d429f10f0",
    "url": "assets/img/home.d698c029.png"
  },
  {
    "revision": "4c0f345b08921741cb99bd75fa146b80",
    "url": "assets/img/friend.4c0f345b.svg"
  },
  {
    "revision": "2b28af66c300d57309fc26499994c5b5",
    "url": "assets/img/details.2b28af66.png"
  },
  {
    "revision": "5d731b23c764005f3494bfeff33b940e",
    "url": "assets/img/commodity.5d731b23.png"
  },
  {
    "revision": "223ef3d305fe84f2c1a5affc992e6c23",
    "url": "assets/img/action.223ef3d3.png"
  },
  {
    "revision": "e319b24008a968815be5",
    "url": "assets/css/chunk-vendors.b57e4bfb.css"
  },
  {
    "revision": "2085bd7cfb459800397a",
    "url": "assets/css/app.f1083e28.css"
  }
];