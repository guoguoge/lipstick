self.__precacheManifest = [
  {
    "revision": "cdf6014420213b057526",
    "url": "js/home.ded1de59.js"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "robots.txt"
  },
  {
    "revision": "4922fb7def2297743dc0",
    "url": "js/layout.3b95f564.js"
  },
  {
    "revision": "640e50a67ab7ce9db337",
    "url": "js/actionCommodityDetail~addAddress~address~balance~binding~center~changePassword~commodityDetail~login~62e71851.a9df97cc.js"
  },
  {
    "revision": "9ed7ef95981f460f0435",
    "url": "js/actionCommodityDetail~commodityDetail.6d3f4055.js"
  },
  {
    "revision": "495e148453d0ddf15a25",
    "url": "js/action~actionCommodityDetail~commodityDetail~home.047e0876.js"
  },
  {
    "revision": "3aa138bc85e8403712e9",
    "url": "js/action~home.848c400c.js"
  },
  {
    "revision": "90328a82a0482f3692d4",
    "url": "js/addAddress.81bb95df.js"
  },
  {
    "revision": "03225ab60f291b3248b2",
    "url": "js/addAddress~address~balance~binding~center~changePassword~login~password~recharge~recordAuction~recor~52f993e1.8f0dc501.js"
  },
  {
    "revision": "80b0b43438d132706177",
    "url": "js/address.c1bc102c.js"
  },
  {
    "revision": "4312fcd1a088e9c57569",
    "url": "js/address~recordAuction~recordLipstick~recordTreasure.7c85ab67.js"
  },
  {
    "revision": "cab7e2cf67e2391d2df2",
    "url": "js/withdrawal.318ead72.js"
  },
  {
    "revision": "2a53426bda99bd86613c",
    "url": "js/app.3ef9c2df.js"
  },
  {
    "revision": "4f577b810c9f1dfb1315",
    "url": "js/balance.2902d6a3.js"
  },
  {
    "revision": "f132c9db6e2983a82ce9",
    "url": "js/balance~center.2fea48c3.js"
  },
  {
    "revision": "40e86203b66715f07952",
    "url": "js/binding.b52e768e.js"
  },
  {
    "revision": "ed8bd5ba30c20d974c16",
    "url": "js/center.7f5cb7cf.js"
  },
  {
    "revision": "ddc22d7d0702c3a51bd5",
    "url": "js/changePassword.c89ff4f9.js"
  },
  {
    "revision": "fa1437b83d466506f9f8",
    "url": "js/register.03fbf556.js"
  },
  {
    "revision": "60fdb0d0cfe7c50f7f8b",
    "url": "js/chunk-vendors.7649d1c5.js"
  },
  {
    "revision": "ae505e64ac76a5be10d2",
    "url": "js/commodityDetail.6176bf0f.js"
  },
  {
    "revision": "47338de1ddd93c1b8df7",
    "url": "js/game.4680197e.js"
  },
  {
    "revision": "075c66111c10716b9ece",
    "url": "js/recordTreasure.1e667d05.js"
  },
  {
    "revision": "5de4b55c490e597dbba9",
    "url": "js/actionCommodityDetail~addAddress~commodityDetail.efce13d8.js"
  },
  {
    "revision": "3febc3932d87cabe237e",
    "url": "js/login.3231d516.js"
  },
  {
    "revision": "062f9fc749bf2f6dd602",
    "url": "js/password.c1c85195.js"
  },
  {
    "revision": "8542c234304226386bac",
    "url": "js/recharge.30ce7f23.js"
  },
  {
    "revision": "9ae1476cbd43217f490c",
    "url": "js/recharge~withdrawal.d10de782.js"
  },
  {
    "revision": "bbd5acb536095e60416c",
    "url": "js/recordAuction.6e478b2d.js"
  },
  {
    "revision": "2e8b2bda8ecb2e65d24d",
    "url": "js/recordLipstick.49422ee7.js"
  },
  {
    "revision": "019791d75c9a15f888547364fcf54d8f",
    "url": "img/wechatpay.019791d7.png"
  },
  {
    "revision": "18e808968fcbd3174bcd",
    "url": "js/actionCommodityDetail.d6c67712.js"
  },
  {
    "revision": "4c0f345b08921741cb99bd75fa146b80",
    "url": "img/friend.4c0f345b.svg"
  },
  {
    "revision": "44a9331c0d8b53bde20a",
    "url": "js/action.aca6a81c.js"
  },
  {
    "revision": "70fad0bc258b903eb39550ab3eacbeaa",
    "url": "img/tab02active.70fad0bc.png"
  },
  {
    "revision": "33874ca52c52c9f75f61e8d18de988d0",
    "url": "img/tab01.33874ca5.png"
  },
  {
    "revision": "7941ae6de899140024f5a5f4ff0fab8e",
    "url": "index.html"
  },
  {
    "revision": "5d73e51ae17cbff2cb6fd6ee30308c25",
    "url": "img/tab01active.5d73e51a.png"
  },
  {
    "revision": "72a3c6bd0f41fbbcb4e1d1b1347abd76",
    "url": "img/wechat.72a3c6bd.svg"
  },
  {
    "revision": "fd7d2a8cc51e058554477c33f27e24bd",
    "url": "img/logo.fd7d2a8c.png"
  },
  {
    "revision": "2b28af66c300d57309fc26499994c5b5",
    "url": "img/details.2b28af66.png"
  },
  {
    "revision": "5d731b23c764005f3494bfeff33b940e",
    "url": "img/commodity.5d731b23.png"
  },
  {
    "revision": "0c3e68838da026adc9516d63ed20e3fe",
    "url": "img/avater.0c3e6883.png"
  },
  {
    "url": "assets/css/chunk-vendors.60fdb0d0cfe7c50f7f8b.1555932297675.css"
  },
  {
    "url": "assets/css/app.2a53426bda99bd86613c.1555932297675.css"
  }
];