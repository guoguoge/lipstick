self.__precacheManifest = [
  {
    "revision": "cdb25e0d314d650a466f",
    "url": "assets/js/recharge~withdrawal.3183e02f.js"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "robots.txt"
  },
  {
    "revision": "40e85c71e671b828d3ad",
    "url": "assets/js/recordAuction.504ae767.js"
  },
  {
    "revision": "54a9f4504d2b7fb4fd3e",
    "url": "assets/js/addAddress~address~balance~binding~center~changePassword~login~password~recharge~recordAuction~recor~52f993e1.a4ec1d3c.js"
  },
  {
    "revision": "7ec91a1bb81c7708cae9",
    "url": "assets/js/address.620ac660.js"
  },
  {
    "revision": "e066a35c490a6059cab5",
    "url": "assets/js/address~recordAuction~recordLipstick~recordTreasure.8288e32e.js"
  },
  {
    "revision": "3ab2951e406ec767e733f31da3e7b064",
    "url": "index.html"
  },
  {
    "revision": "4e1a9aa2c54c029225b7",
    "url": "assets/js/app.3ec5a36d.js"
  },
  {
    "revision": "c5502926f28dae500f5c",
    "url": "assets/js/balance.57e2ffed.js"
  },
  {
    "revision": "573e8589c05374443f65",
    "url": "assets/js/balance~center.cdb835a3.js"
  },
  {
    "revision": "2c8019cc325b730c49a4",
    "url": "assets/js/binding.7743d546.js"
  },
  {
    "revision": "f0ae1df806597c104351",
    "url": "assets/js/center.c3ff28ee.js"
  },
  {
    "revision": "166a5d9680e7c936811c",
    "url": "assets/js/changePassword.e7e2b000.js"
  },
  {
    "revision": "0fee9c2cae12894e9787",
    "url": "assets/js/withdrawal.847367d3.js"
  },
  {
    "revision": "e319b24008a968815be5",
    "url": "assets/js/chunk-vendors.9a9da8f9.js"
  },
  {
    "revision": "9eeba990057c8ab1da26",
    "url": "assets/js/commodityDetail.213967d7.js"
  },
  {
    "revision": "32b378073d61e6f9c47d",
    "url": "assets/js/home.1ace3e4c.js"
  },
  {
    "revision": "44170debdbd0ee02e392",
    "url": "assets/js/layout.17152dd2.js"
  },
  {
    "revision": "4af6f53b8d25339351d1",
    "url": "assets/js/login.5bd0bdae.js"
  },
  {
    "revision": "35776d8b6dfe417ad6fe",
    "url": "assets/js/password.13b04a03.js"
  },
  {
    "revision": "6036df5c46d81654fa9a",
    "url": "assets/js/recharge.d2114799.js"
  },
  {
    "revision": "e725b977a9a17fc3d5c2",
    "url": "assets/js/register.b2653a19.js"
  },
  {
    "revision": "ae634eafe966c279bfc0",
    "url": "assets/js/addAddress~commodityDetail.9c0d2d44.js"
  },
  {
    "revision": "0241692801589dda15dc",
    "url": "assets/js/recordLipstick.84840aa6.js"
  },
  {
    "revision": "6e080d741265a551684c",
    "url": "assets/js/recordTreasure.066d6283.js"
  },
  {
    "revision": "019791d75c9a15f888547364fcf54d8f",
    "url": "assets/img/wechatpay.019791d7.png"
  },
  {
    "revision": "8ec1307ddac2e60158e7",
    "url": "assets/js/addAddress~address~balance~binding~center~changePassword~commodityDetail~login~password~recharge~rec~209abe2d.7ff96fa3.js"
  },
  {
    "revision": "4c0f345b08921741cb99bd75fa146b80",
    "url": "assets/img/friend.4c0f345b.svg"
  },
  {
    "revision": "641af3a853251ab66616",
    "url": "assets/js/addAddress.9f0e56d6.js"
  },
  {
    "revision": "a1655319df073d847ac75abb99c2191d",
    "url": "assets/img/tab02active.a1655319.png"
  },
  {
    "revision": "72a3c6bd0f41fbbcb4e1d1b1347abd76",
    "url": "assets/img/wechat.72a3c6bd.svg"
  },
  {
    "revision": "f17e252f3b13f9fe18b08a4439545ce3",
    "url": "assets/img/tab01active.f17e252f.png"
  },
  {
    "revision": "bd1b7e2561c2c64bed70206196ff2f9b",
    "url": "assets/img/tab04.bd1b7e25.png"
  },
  {
    "revision": "eb1b619f05c30af3ede483501426cee6",
    "url": "assets/img/tab04active.eb1b619f.png"
  },
  {
    "revision": "b3d1b5709d42fa6e46d19a978ba67b77",
    "url": "assets/img/tab02.b3d1b570.png"
  },
  {
    "revision": "8739a163bbff2a38a984cd43639ffecb",
    "url": "assets/img/tab01.8739a163.png"
  },
  {
    "revision": "fd7d2a8cc51e058554477c33f27e24bd",
    "url": "assets/img/logo.fd7d2a8c.png"
  },
  {
    "revision": "d698c02937cd281ab1a2ed7d429f10f0",
    "url": "assets/img/home.d698c029.png"
  },
  {
    "revision": "2b28af66c300d57309fc26499994c5b5",
    "url": "assets/img/details.2b28af66.png"
  },
  {
    "revision": "5d731b23c764005f3494bfeff33b940e",
    "url": "assets/img/commodity.5d731b23.png"
  },
  {
    "revision": "e319b24008a968815be5",
    "url": "assets/css/chunk-vendors.b57e4bfb.css"
  },
  {
    "revision": "4e1a9aa2c54c029225b7",
    "url": "assets/css/app.f1083e28.css"
  }
];