self.__precacheManifest = [
  {
    "url": "assets/js/1562148609043-layout.afc318015085115c587d.js"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "robots.txt"
  },
  {
    "url": "assets/js/1562148609043-login.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-actionCommodityDetail~addAddress~address~balance~binding~center~changePassword~commodityDetail~login~c134ccbc.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-action~actionCommodityDetail~addAddress~address~balance~binding~center~changePassword~commodityDetai~f7a3dc4a.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-action~actionCommodityDetail~commodityDetail~home.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-action~home.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-addAddress.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-addAddress~address~balance~binding~center~changePassword~login~password~recharge~recordAuction~recor~0872f388.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-address.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-address~recordTreasure.afc318015085115c587d.js"
  },
  {
    "revision": "08cec7b92c2077cd63e293e330a2f86e",
    "url": "index.html"
  },
  {
    "url": "assets/js/1562148609043-app.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-balance.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-balance~center.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-binding.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-center.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-changePassword.afc318015085115c587d.js"
  },
  {
    "revision": "fd7d2a8cc51e058554477c33f27e24bd",
    "url": "img/logo.fd7d2a8c.png"
  },
  {
    "url": "assets/js/1562148609043-chunk-vendors.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-commodityDetail.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-game.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-home.afc318015085115c587d.js"
  },
  {
    "revision": "0c3e68838da026adc9516d63ed20e3fe",
    "url": "img/avater.0c3e6883.png"
  },
  {
    "url": "assets/js/1562148609043-actionCommodityDetail~addAddress~binding~commodityDetail.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-password.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-recharge.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-recharge~withdrawal.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-recordAuction.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-recordAuction~recordWithdraw.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-recordLipstick.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-recordTreasure.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-recordWithdraw.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-register.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-withdrawal.afc318015085115c587d.js"
  },
  {
    "revision": "72a3c6bd0f41fbbcb4e1d1b1347abd76",
    "url": "img/wechat.72a3c6bd.svg"
  },
  {
    "revision": "33874ca52c52c9f75f61e8d18de988d0",
    "url": "img/tab01.33874ca5.png"
  },
  {
    "revision": "d72a2584cc8e7ef1d59f9089948d0697",
    "url": "img/noimg.d72a2584.png"
  },
  {
    "revision": "019791d75c9a15f888547364fcf54d8f",
    "url": "img/wechatpay.019791d7.png"
  },
  {
    "revision": "4c0f345b08921741cb99bd75fa146b80",
    "url": "img/friend.4c0f345b.svg"
  },
  {
    "revision": "70fad0bc258b903eb39550ab3eacbeaa",
    "url": "img/tab02active.70fad0bc.png"
  },
  {
    "revision": "5d73e51ae17cbff2cb6fd6ee30308c25",
    "url": "img/tab01active.5d73e51a.png"
  },
  {
    "url": "assets/js/1562148609043-actionCommodityDetail.afc318015085115c587d.js"
  },
  {
    "url": "assets/js/1562148609043-action.afc318015085115c587d.js"
  },
  {
    "url": "assets/css/chunk-vendors.cfa2659c32f132801d95.1562148609043.css"
  },
  {
    "url": "assets/css/app.0016bd7b75ce6913bc29.1562148609043.css"
  }
];