self.__precacheManifest = [
  {
    "url": "assets/js/1561632041421-layout.024522a81ec931925c95.js"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "robots.txt"
  },
  {
    "url": "assets/js/1561632041421-login.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-actionCommodityDetail~addAddress~address~balance~binding~center~changePassword~commodityDetail~login~c134ccbc.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-action~actionCommodityDetail~addAddress~address~balance~binding~center~changePassword~commodityDetai~f7a3dc4a.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-action~actionCommodityDetail~commodityDetail~home.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-action~home.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-addAddress.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-addAddress~address~balance~binding~center~changePassword~login~password~recharge~recordAuction~recor~0872f388.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-address.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-address~recordTreasure.024522a81ec931925c95.js"
  },
  {
    "revision": "8af21d3d21005c9c3c6843253e2239ff",
    "url": "index.html"
  },
  {
    "url": "assets/js/1561632041421-app.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-balance.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-balance~center.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-binding.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-center.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-changePassword.024522a81ec931925c95.js"
  },
  {
    "revision": "fd7d2a8cc51e058554477c33f27e24bd",
    "url": "img/logo.fd7d2a8c.png"
  },
  {
    "url": "assets/js/1561632041421-chunk-vendors.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-commodityDetail.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-game.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-home.024522a81ec931925c95.js"
  },
  {
    "revision": "0c3e68838da026adc9516d63ed20e3fe",
    "url": "img/avater.0c3e6883.png"
  },
  {
    "url": "assets/js/1561632041421-actionCommodityDetail~addAddress~binding~commodityDetail.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-password.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-recharge.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-recharge~withdrawal.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-recordAuction.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-recordAuction~recordWithdraw.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-recordLipstick.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-recordTreasure.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-recordWithdraw.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-register.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-withdrawal.024522a81ec931925c95.js"
  },
  {
    "revision": "72a3c6bd0f41fbbcb4e1d1b1347abd76",
    "url": "img/wechat.72a3c6bd.svg"
  },
  {
    "revision": "33874ca52c52c9f75f61e8d18de988d0",
    "url": "img/tab01.33874ca5.png"
  },
  {
    "revision": "d72a2584cc8e7ef1d59f9089948d0697",
    "url": "img/noimg.d72a2584.png"
  },
  {
    "revision": "019791d75c9a15f888547364fcf54d8f",
    "url": "img/wechatpay.019791d7.png"
  },
  {
    "revision": "4c0f345b08921741cb99bd75fa146b80",
    "url": "img/friend.4c0f345b.svg"
  },
  {
    "revision": "70fad0bc258b903eb39550ab3eacbeaa",
    "url": "img/tab02active.70fad0bc.png"
  },
  {
    "revision": "5d73e51ae17cbff2cb6fd6ee30308c25",
    "url": "img/tab01active.5d73e51a.png"
  },
  {
    "url": "assets/js/1561632041421-actionCommodityDetail.024522a81ec931925c95.js"
  },
  {
    "url": "assets/js/1561632041421-action.024522a81ec931925c95.js"
  },
  {
    "url": "assets/css/chunk-vendors.cfa2659c32f132801d95.1561632041421.css"
  },
  {
    "url": "assets/css/app.e9a30c5a21667de4a28f.1561632041421.css"
  }
];