self.__precacheManifest = [
  {
    "url": "assets/js/1562579593880-home.8be61a7345d0b021be79.js"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "robots.txt"
  },
  {
    "url": "assets/js/1562579593880-layout.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-actionCommodityDetail~addAddress~address~balance~bindLogin~binding~center~changePassword~commodityDe~3fd8423a.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-action~actionCommodityDetail~addAddress~address~balance~bindLogin~binding~center~changePassword~comm~812143f1.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-action~actionCommodityDetail~commodityDetail~home.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-action~home.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-addAddress.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-addAddress~address~balance~bindLogin~binding~center~changePassword~login~password~recharge~recordAuc~14bd8598.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-address.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-address~recordTreasure.8be61a7345d0b021be79.js"
  },
  {
    "revision": "65fdd2959b530b946cb54966b26d59dd",
    "url": "index.html"
  },
  {
    "url": "assets/js/1562579593880-app.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-balance.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-balance~center.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-bindLogin.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-binding.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-center.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-changePassword.8be61a7345d0b021be79.js"
  },
  {
    "revision": "fd7d2a8cc51e058554477c33f27e24bd",
    "url": "img/logo.fd7d2a8c.png"
  },
  {
    "url": "assets/js/1562579593880-chunk-vendors.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-commodityDetail.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-game.8be61a7345d0b021be79.js"
  },
  {
    "revision": "0c3e68838da026adc9516d63ed20e3fe",
    "url": "img/avater.0c3e6883.png"
  },
  {
    "url": "assets/js/1562579593880-actionCommodityDetail~addAddress~bindLogin~binding~commodityDetail.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-login.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-password.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-recharge.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-recharge~withdrawal.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-recordAuction.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-recordAuction~recordWithdraw.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-recordLipstick.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-recordTreasure.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-recordWithdraw.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-register.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-withdrawal.8be61a7345d0b021be79.js"
  },
  {
    "revision": "72a3c6bd0f41fbbcb4e1d1b1347abd76",
    "url": "img/wechat.72a3c6bd.svg"
  },
  {
    "revision": "33874ca52c52c9f75f61e8d18de988d0",
    "url": "img/tab01.33874ca5.png"
  },
  {
    "revision": "d72a2584cc8e7ef1d59f9089948d0697",
    "url": "img/noimg.d72a2584.png"
  },
  {
    "revision": "019791d75c9a15f888547364fcf54d8f",
    "url": "img/wechatpay.019791d7.png"
  },
  {
    "revision": "4c0f345b08921741cb99bd75fa146b80",
    "url": "img/friend.4c0f345b.svg"
  },
  {
    "revision": "70fad0bc258b903eb39550ab3eacbeaa",
    "url": "img/tab02active.70fad0bc.png"
  },
  {
    "revision": "5d73e51ae17cbff2cb6fd6ee30308c25",
    "url": "img/tab01active.5d73e51a.png"
  },
  {
    "url": "assets/js/1562579593880-actionCommodityDetail.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/js/1562579593880-action.8be61a7345d0b021be79.js"
  },
  {
    "url": "assets/css/chunk-vendors.cfa2659c32f132801d95.1562579593880.css"
  },
  {
    "url": "assets/css/app.36483aa60c45ea882683.1562579593880.css"
  }
];